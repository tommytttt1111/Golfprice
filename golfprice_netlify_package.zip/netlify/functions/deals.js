/**
 * Netlify Function: deals
 * Combines one or more sources into a unified deals feed.
 * - Supports a Google Sheet CSV (publish to web) via env SHEET_CSV_URL
 * - Supports extra JSON endpoints via env EXTRA_JSON_URLS (comma-separated)
 * - Bundled local sample at /data/deals-sample.json (used if nothing else)
 *
 * Output schema (array of objects):
 * { title, brand, category, retailer, url, image, currency, price, oldPrice, inStock, updatedAt, affiliateUrl }
 */
import { readFile } from 'fs/promises';

export default async (req, context) => {
  const headers = {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
  };

  try {
    const sheetCsv = process.env.SHEET_CSV_URL || "";
    const extraJson = (process.env.EXTRA_JSON_URLS || "").split(",").map(s => s.trim()).filter(Boolean);

    const pieces = [];

    // 1) Google Sheet CSV -> normalize
    if (sheetCsv) {
      try {
        const res = await fetch(sheetCsv);
        if (!res.ok) throw new Error("Sheet fetch " + res.status);
        const csv = await res.text();
        const rows = parseCSV(csv);
        rows.forEach(r => pieces.push(normalize(r)));
      } catch (e) {
        console.warn("Sheet error:", e.message);
      }
    }

    // 2) Extra JSON endpoints
    for (const url of extraJson) {
      try {
        const res = await fetch(url, { headers: { "accept": "application/json" } });
        if (!res.ok) throw new Error("JSON fetch " + res.status);
        const arr = await res.json();
        if (Array.isArray(arr)) {
          arr.forEach(obj => pieces.push(normalize(obj)));
        }
      } catch (e) {
        console.warn("Extra JSON error:", url, e.message);
      }
    }

    // 3) Local sample as fallback
    if (pieces.length === 0) {
      const data = await readFile(new URL('../../data/deals-sample.json', import.meta.url));
      const arr = JSON.parse(data.toString());
      arr.forEach(obj => pieces.push(normalize(obj)));
    }

    // sort best discount first
    pieces.sort((a, b) => (pctOff(b.oldPrice, b.price) - pctOff(a.oldPrice, a.price)));

    return new Response(JSON.stringify(pieces, null, 2), { status: 200, headers });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers });
  }
};

function parseCSV(csv) {
  // naive CSV parser: expects header row
  const lines = csv.trim().split(/\r?\n/);
  const headers = lines.shift().split(",").map(s => s.trim());
  return lines.map(line => {
    const cells = splitCsvLine(line);
    const obj = {};
    headers.forEach((h, i) => obj[h] = (cells[i] ?? "").trim());
    return obj;
  });
}
function splitCsvLine(line) {
  const out = []; let cur = ""; let q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"' ) {
      if (q && line[i+1] === '"') { cur += '"'; i++; }
      else q = !q;
    } else if (c === ',' && !q) { out.push(cur); cur = ""; }
    else { cur += c; }
  }
  out.push(cur);
  return out;
}

function normalize(x) {
  const asNum = (v) => {
    const n = Number(String(v||"").replace(/[^0-9.\-]/g, ""));
    return isFinite(n) ? n : undefined;
  };
  const truthy = (v) => {
    const s = String(v||"").toLowerCase();
    return ["true","1","yes","y"].includes(s);
  };
  const nowIso = new Date().toISOString();

  return {
    title: x.title || x.name || "",
    brand: x.brand || "",
    category: x.category || "",
    retailer: x.retailer || x.store || "",
    url: x.url || "",
    image: x.image || x.imageUrl || "",
    currency: x.currency || "USD",
    price: asNum(x.price),
    oldPrice: asNum(x.oldPrice),
    inStock: x.inStock !== undefined ? truthy(x.inStock) : true,
    updatedAt: x.updatedAt || nowIso,
    affiliateUrl: x.affiliateUrl || x.affUrl || "",
  };
}

function pctOff(oldP, newP) {
  const o = Number(oldP), n = Number(newP);
  if (!o || !n) return 0;
  return Math.round((1 - n/o) * 100);
}
