
Deploy this folder to Netlify (Git import recommended). The Deals tab will use
/.netlify/functions/deals (fallback to /data/deals-sample.json). Configure env vars
SHEET_CSV_URL and EXTRA_JSON_URLS to merge live sources.
