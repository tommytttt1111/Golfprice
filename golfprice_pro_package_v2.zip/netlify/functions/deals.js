
import { readFile } from 'fs/promises';

export default async () => {
  const headers = {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
  };
  try {
    // Fallback to local sample
    const data = await readFile(new URL('../../data/deals-sample.json', import.meta.url));
    return new Response(data.toString(), { status: 200, headers });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers });
  }
};
